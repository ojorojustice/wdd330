import * as ls from "./ls.js";
import {countClick} from "./utilities";

document.addEventListener("DOMContentLoaded", ls.getTodoList);

//selectors


ls.countNotCompleted();
countClick;
